from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('check_flood/', views.check_flood, name='check_flood'),
]
