from django.http import HttpResponse
from django.shortcuts import render
# flood_app/views.py



def home(request):
    """Render the homepage"""
    return render(request, 'alerts/home.html')

from django.shortcuts import render

def assess_flood_risk(rainfall, water_level):
    """Determine flood risk based on user-provided data (rainfall and water level)"""
    
    # Apply flood risk assessment rules
    if rainfall > 100 and water_level >= 5:
        return "High Flood Risk"
    elif rainfall > 50 and water_level > 2:
        return "Medium Flood Risk"
    return "Low Flood Risk"


def check_flood(request):
    """View to check flood risk for a given city"""
    if request.method == 'POST':
        city_name = request.POST.get('city')
        try:
            rainfall = float(request.POST.get('rainfall'))  # Get rainfall from the form input
            water_level = float(request.POST.get('water_level'))  # Get water level from the form input
        except ValueError:
            return HttpResponse("Error: Please provide valid numerical values.")

        # Assess flood risk based on rainfall and water level
        flood_risk = assess_flood_risk(rainfall, water_level)

        # Return result
        return render(request, 'alerts/home.html', {
            'city_name': city_name,
            'flood_risk': flood_risk
        })
    
    return render(request, 'alerts/home.html')
